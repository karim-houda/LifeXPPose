# LifeXPPose consumer rules
