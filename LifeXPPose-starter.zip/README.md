# LifeXPPose

Starter Android library project for LifeXP pose detection using MediaPipe Tasks Vision.

## Required model asset

Before building, download the official Pose Landmarker Lite model and place it at:

`lifexppose/src/main/assets/pose_landmarker_lite.task`

Official model URL:
https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task

The model is not bundled in this ZIP because the download could not be verified from this environment.

## Build

Push to the `main` branch or manually run the `Build LifeXPPose` workflow from GitHub Actions.

Artifact output: `lifexppose/build/outputs/aar/lifexppose-release.aar`

## Current scope

This starter detects pose landmarks in a single `Bitmap` in IMAGE mode. It does not yet provide live camera streaming, a drawing overlay, or exercise repetition counting. Those need to be implemented and tested after the library builds successfully.
